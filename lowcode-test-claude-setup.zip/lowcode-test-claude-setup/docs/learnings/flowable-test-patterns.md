# Flowable Test Patterns

## FlowableTestHelper Usage
```java
@TenantIntegrationTest
class LoanApprovalProcessIT {

  @Autowired FlowableTestHelper flowable;
  @Autowired TenantTestFixture tenant;

  @BeforeEach void setup() {
    tenant.provision("test-enterprise");
    flowable.deployBpmn("test-enterprise", "bpmn/LoanApproval.bpmn20.xml");
  }

  @AfterEach void cleanup() {
    flowable.deleteAllProcessInstances("test-enterprise");
    tenant.teardown("test-enterprise");
  }

  @Test void processStart_createsTaskForApprovalGroup() {
    String instanceId = flowable.startProcess(
      "test-enterprise", "LoanApprovalProcess", "LOAN-001",
      Map.of("loanAmount", 50000, "applicantId", "APP-123")
    );

    List<Task> tasks = flowable.getTasks("test-enterprise", instanceId);
    assertThat(tasks).hasSize(1)
      .first()
      .satisfies(t -> {
        assertThat(t.getTaskDefinitionKey()).isEqualTo("l1ApprovalTask");
        assertThat(t.getCandidateGroups()).contains("L1_APPROVERS");
      });
  }
}
```

## Concurrent Claim Test Pattern
```java
@Test void concurrentClaim_tenThreads_onlyOneSucceeds() throws Exception {
  String taskId = flowable.createTask("test-enterprise", "approvalTask");
  ExecutorService pool = Executors.newFixedThreadPool(10);
  AtomicInteger successCount = new AtomicInteger(0);
  AtomicInteger conflictCount = new AtomicInteger(0);
  CountDownLatch latch = new CountDownLatch(10);

  for (int i = 0; i < 10; i++) {
    final String userId = "user-" + i;
    pool.submit(() -> {
      try {
        taskService.claimTask("test-enterprise", taskId, userId);
        successCount.incrementAndGet();
      } catch (TaskAlreadyClaimedException e) {
        conflictCount.incrementAndGet();
      } finally {
        latch.countDown();
      }
    });
  }

  latch.await(10, SECONDS);
  assertThat(successCount.get()).isEqualTo(1);
  assertThat(conflictCount.get()).isEqualTo(9);
}
```

## Idempotency Test Pattern
```java
@Test void processStart_calledTwiceWithSameIdempotencyKey_onlyOneInstance() {
  String idempotencyKey = UUID.randomUUID().toString();

  processService.start("test-enterprise", "LoanApproval", "LOAN-001",
    Map.of(), idempotencyKey);
  processService.start("test-enterprise", "LoanApproval", "LOAN-001",
    Map.of(), idempotencyKey); // second call — same key

  long count = flowable.countInstances("test-enterprise", "LoanApproval");
  assertThat(count).isEqualTo(1); // only one created
}
```

## Async History Assertion Pattern
```java
// WRONG — flaky, history is async
taskService.complete("test-enterprise", taskId, "APPROVED", Map.of());
assertThat(historyService.findByTaskId(taskId)).isNotNull(); // ← may be null

// CORRECT — wait for async history
taskService.complete("test-enterprise", taskId, "APPROVED", Map.of());
await().atMost(5, SECONDS)
  .pollInterval(200, MILLISECONDS)
  .until(() -> historyService.findByTaskId(taskId) != null);
assertThat(historyService.findByTaskId(taskId))
  .extracting("outcome").isEqualTo("APPROVED");
```

## Dead Letter Test Pattern
```java
@Test void jobFailsThreeTimes_landsInDeadLetter() {
  // Deploy BPMN with service task that always throws
  flowable.deployBpmn("test-enterprise", "bpmn/FailingServiceTask.bpmn20.xml");
  flowable.startProcess("test-enterprise", "FailingProcess", "FAIL-001", Map.of());

  // Wait for 3 retry attempts (exponential backoff: 1s + 2s + 4s ≈ 10s)
  await().atMost(30, SECONDS)
    .until(() -> flowable.deadLetterJobCount("test-enterprise") > 0);

  assertThat(flowable.deadLetterJobs("test-enterprise"))
    .hasSize(1)
    .first()
    .satisfies(job -> assertThat(job.getExceptionMessage()).contains("FailingServiceTask"));

  // Verify dead letter event on Kafka
  kafkaHelper.assertEventPublished("test-enterprise.deadletter",
    event -> event.get("businessKey").asText().equals("FAIL-001"));
}
```

## Claim Check Test Pattern
```java
@Test void variable_exceeds10KB_storedAsReference() {
  byte[] largePayload = new byte[15 * 1024]; // 15KB
  new Random().nextBytes(largePayload);

  String instanceId = flowable.startProcess("test-enterprise", "ClaimCheckProcess",
    "CC-001", Map.of("applicationData", largePayload));

  // Verify: Flowable variable contains reference, not payload
  Object variable = flowable.getVariable("test-enterprise", instanceId, "applicationData");
  assertThat(variable).isNull(); // direct variable not set

  Object ref = flowable.getVariable("test-enterprise", instanceId, "applicationData__ref");
  assertThat(ref).isInstanceOf(String.class).asString().isNotBlank();

  // Verify: payload retrievable from Data Service via ref
  Object retrieved = claimCheckService.retrieve("test-enterprise", instanceId, "applicationData");
  assertThat(retrieved).isEqualTo(largePayload);
}
```

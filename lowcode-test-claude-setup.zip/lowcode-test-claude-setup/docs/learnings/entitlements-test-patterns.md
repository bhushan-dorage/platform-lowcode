# Entitlements Test Patterns

## EntitlementTestHelper Usage
```java
@TenantIntegrationTest
class DataPolicyIT {

  @Autowired EntitlementTestHelper entitlements;
  @Autowired TenantTestFixture tenant;

  @BeforeEach void setup() {
    tenant.provision("test-enterprise");
    // Create L1_APPROVER role with branch-scoped data policy
    entitlements.createRole("test-enterprise", "L1_APPROVER");
    entitlements.setDataPolicy("test-enterprise", "L1_APPROVER", "LoanApplication",
      DataPolicy.read()
        .condition("branchId", Op.EQUALS, "${actor.attributes.branchId}")
        .condition("loanAmount", Op.LESS_THAN_OR_EQUAL, "${actor.attributes.sanctioningLimit}")
        .condition("status", Op.NOT_IN, List.of("DRAFT", "SYSTEM_HOLD"))
    );
    entitlements.setActorAttributes("test-enterprise", "user-l1",
      Map.of("branchId", "BR-001", "sanctioningLimit", "100000")
    );
  }
}
```

## Data Policy Isolation Test Pattern
```java
@Test void l1Approver_seesOnlyOwnBranchLoans() {
  // Setup: loans in two branches
  dataService.create("test-enterprise", "LoanApplication",
    Map.of("businessKey","LOAN-001","branchId","BR-001","loanAmount",50000,"status","PENDING"));
  dataService.create("test-enterprise", "LoanApplication",
    Map.of("businessKey","LOAN-002","branchId","BR-002","loanAmount",50000,"status","PENDING"));

  // Act: query as L1 approver from BR-001
  String token = keycloakHelper.getToken("test-enterprise", "user-l1", List.of("L1_APPROVER"));
  List<Map> results = entityClient.list("test-enterprise", "LoanApplication", token);

  // Assert: only BR-001 loan visible
  assertThat(results).hasSize(1)
    .first().extracting("businessKey").isEqualTo("LOAN-001");
}

@Test void l1Approver_cannotSeeOtherBranchLoan_singleRecordFetch() {
  dataService.create("test-enterprise", "LoanApplication",
    Map.of("businessKey","LOAN-003","branchId","BR-002","loanAmount",50000,"status","PENDING"));

  String token = keycloakHelper.getToken("test-enterprise", "user-l1", List.of("L1_APPROVER"));

  // Post-fetch assertion must reject cross-branch single record access
  assertThatThrownBy(() ->
    entityClient.findByBusinessKey("test-enterprise", "LoanApplication", "LOAN-003", token))
    .isInstanceOf(PlatformAccessDeniedException.class)
    .hasMessageContaining("DATA_POLICY_VIOLATION");
}
```

## Field Level Test Patterns
```java
@Test void viewer_panField_returnsMasked() {
  dataService.create("test-enterprise", "LoanApplication",
    Map.of("businessKey","LOAN-004","pan","ABCDE1234F","status","PENDING"));

  // Set field policy: VIEWER can read PAN but it's MASKED
  entitlements.setFieldPolicy("test-enterprise", "VIEWER", "LoanApplication",
    FieldPolicy.of("pan", Access.MASKED, "first4Last1")); // ABCDE****F

  String token = keycloakHelper.getToken("test-enterprise", "user-viewer", List.of("VIEWER"));
  Map result = entityClient.findByBusinessKey("test-enterprise", "LoanApplication", "LOAN-004", token);

  assertThat(result.get("pan").toString())
    .matches("ABCD\\*+F") // masked pattern
    .doesNotContain("1234"); // raw value never appears
}

@Test void viewer_cannotWritePanField_returns403() {
  String token = keycloakHelper.getToken("test-enterprise", "user-viewer", List.of("VIEWER"));

  assertThatThrownBy(() ->
    entityClient.patch("test-enterprise", "LoanApplication", "LOAN-004",
      Map.of("pan", "ZZZZZ9999Z"), token))
    .isInstanceOf(PlatformAccessDeniedException.class)
    .hasMessageContaining("FIELD_ACCESS_DENIED");
}

@Test void denyField_completelyAbsentFromResponse() {
  entitlements.setFieldPolicy("test-enterprise", "VIEWER", "LoanApplication",
    FieldPolicy.of("internalCreditScore", Access.DENY));

  String token = keycloakHelper.getToken("test-enterprise", "user-viewer", List.of("VIEWER"));
  Map result = entityClient.findByBusinessKey("test-enterprise", "LoanApplication", "LOAN-004", token);

  assertThat(result).doesNotContainKey("internalCreditScore"); // key absent, not null
}
```

## Cache Invalidation Test
```java
@Test void policyChange_cacheInvalidated_within5Seconds() {
  // Initial policy: loanAmount <= 100000
  entitlements.setDataPolicy("test-enterprise", "L1_APPROVER", "LoanApplication",
    DataPolicy.read().condition("loanAmount", Op.LESS_THAN_OR_EQUAL, "100000"));

  dataService.create("test-enterprise", "LoanApplication",
    Map.of("businessKey","LOAN-005","branchId","BR-001","loanAmount",200000,"status","PENDING"));

  String token = keycloakHelper.getToken("test-enterprise", "user-l1", List.of("L1_APPROVER"));

  // Before policy change: 200k loan not visible (exceeds 100k limit)
  assertThat(entityClient.list("test-enterprise", "LoanApplication", token)).isEmpty();

  // Change policy: raise limit to 500000
  entitlements.setDataPolicy("test-enterprise", "L1_APPROVER", "LoanApplication",
    DataPolicy.read().condition("loanAmount", Op.LESS_THAN_OR_EQUAL, "500000"));

  // After change: cache should invalidate within 5s
  await().atMost(5, SECONDS).pollInterval(500, MILLISECONDS)
    .until(() -> entityClient.list("test-enterprise", "LoanApplication", token).size() == 1);
}
```

## ACCESS_DENIED Audit Event Assertion
```java
@Test void accessDenied_publishesAuditEvent() {
  String token = keycloakHelper.getToken("test-enterprise", "user-viewer", List.of("VIEWER"));

  // Trigger access denial
  assertThatThrownBy(() ->
    entityClient.patch("test-enterprise", "LoanApplication", "LOAN-004",
      Map.of("pan", "NEW_VALUE"), token))
    .isInstanceOf(PlatformAccessDeniedException.class);

  // Verify audit event published
  auditVerifier.assertEvent("test-enterprise", "ACCESS_DENIED", "LOAN-004",
    event -> event.getAction().getDenialReason().equals("FIELD_ACCESS_DENIED")
              && event.getActor().getUserId().equals("user-viewer")
  );
}
```

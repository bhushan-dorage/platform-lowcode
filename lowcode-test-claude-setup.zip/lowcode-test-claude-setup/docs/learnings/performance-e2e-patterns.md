# Performance & E2E Test Patterns

## Gatling Simulation Structure
```scala
class ProcessStartBurstSimulation extends Simulation {

  val sitUrl = System.getenv("PLATFORM_SIT_URL")
  val token  = System.getenv("PLATFORM_SIT_TOKEN")

  val httpConf = http.baseUrl(sitUrl)
    .header("Authorization", s"Bearer $token")
    .header("X-Tenant-ID", "perf-test-enterprise")
    .header("Content-Type", "application/json")

  val processStart = scenario("ProcessStartBurst")
    .exec(
      http("Submit Loan Application")
        .post("/api/v1/processes")
        .header("Idempotency-Key", "#{idempotencyKey}")
        .body(StringBody("""{"processKey":"LoanApproval","businessKey":"#{businessKey}"}"""))
        .check(status.is(202))
        .check(jsonPath("$.data.trackingId").saveAs("trackingId"))
    )
    .exec(
      http("Poll Process Status")
        .get("/api/v1/processes/#{trackingId}/status")
        .check(status.is(200))
        .check(jsonPath("$.data.status").is("ACTIVE"))
    )

  setUp(
    processStart.inject(
      rampUsers(500).during(60.seconds)  // ramp to 500 VU over 1 min
    ).protocols(httpConf)
  ).assertions(
    global.responseTime.percentile(99).lt(2000),  // p99 < 2s
    global.failedRequests.percent.lt(1)           // < 1% failure
  )
}
```

## Loading and Comparing Baseline
```scala
// In BaseSimulation.scala (shared):
def loadBaseline(scenario: String): Map[String, Double] = {
  val json = Source.fromResource(s"baselines/${scenario}_baseline.json").mkString
  parse(json).as[Map[String, Double]].getOrElse(Map.empty)
}

// In each simulation:
val baseline = loadBaseline("ProcessStartBurst")
setUp(...).assertions(
  global.responseTime.percentile(99)
    .lt((baseline("p99") * 1.10).toInt)  // fail if > 10% regression
)
```

## Multi-Tenant Load (always use 3+ tenants)
```scala
val tenants = List("perf-enterprise-a", "perf-enterprise-b", "perf-professional-a")
val feeder  = Iterator.continually(Map(
  "tenantId"       -> tenants(Random.nextInt(tenants.size)),
  "businessKey"    -> s"LOAN-${UUID.randomUUID()}",
  "idempotencyKey" -> UUID.randomUUID().toString
))
```

## Playwright E2E Structure
```typescript
// tests/loan-application-flow.spec.ts
import { test, expect } from '@playwright/test';
import { TenantSetup } from '../fixtures/TenantSetup';

test.describe('Loan Application Full Flow', () => {
  let tenantSetup: TenantSetup;
  const runId = Date.now();

  test.beforeAll(async () => {
    tenantSetup = await TenantSetup.provision(`e2e-${runId}`);
  });

  test.afterAll(async () => {
    await tenantSetup.teardown();
  });

  test.afterEach(async ({ page }, testInfo) => {
    if (testInfo.status !== 'passed') {
      await page.screenshot({ path: `screenshots/${testInfo.title}-${Date.now()}.png` });
    }
  });

  test('applicant submits → L1 approves → process completes', async ({ browser }) => {
    const applicantCtx = await browser.newContext();
    const approverCtx  = await browser.newContext();
    const applicant    = await applicantCtx.newPage();
    const approver     = await approverCtx.newPage();

    // Step 1: Login as applicant
    await applicant.goto(`${process.env.PLATFORM_SIT_URL}/portal`);
    await tenantSetup.login(applicant, 'applicant-user');

    // Step 2: Submit loan application form
    await applicant.click('[data-testid="start-process-LoanApproval"]');
    await applicant.fill('[name="loanAmount"]', '50000');
    await applicant.fill('[name="applicantName"]', 'John Doe');
    await applicant.click('[data-testid="submit-form"]');
    await expect(applicant.locator('[data-testid="submission-success"]')).toBeVisible();

    // Step 3: Login as L1 approver
    await tenantSetup.login(approver, 'l1-approver-user');
    await approver.goto(`${process.env.PLATFORM_SIT_URL}/portal/tasks`);

    // Step 4: Verify task appears in inbox
    await expect(approver.locator('[data-testid="task-row"]').filter({ hasText: 'John Doe' }))
      .toBeVisible({ timeout: 10000 });

    // Step 5: Claim and complete task
    await approver.click('[data-testid="claim-task"]');
    await approver.selectOption('[name="decision"]', 'APPROVE');
    await approver.click('[data-testid="complete-task"]');

    // Step 6: Verify process completed
    await expect(approver.locator('[data-testid="process-status"]'))
      .toContainText('COMPLETED', { timeout: 15000 });
  });
});
```

## Tenant Isolation E2E Pattern
```typescript
test('two tenants cannot see each other tasks', async ({ browser }) => {
  const hsbcCtx  = await browser.newContext();
  const iciciCtx = await browser.newContext();
  const hsbcPage  = await hsbcCtx.newPage();
  const iciciPage = await iciciCtx.newPage();

  // Create task for hsbc tenant
  await tenantSetup.createTask(`e2e-${runId}`, 'LOAN-HSBC-001');

  // Login as hsbc user → sees their task
  await tenantSetup.login(hsbcPage, 'hsbc-user');
  await expect(hsbcPage.locator('[data-testid="task-row"]')).toHaveCount(1);

  // Login as icici user → sees zero tasks
  await tenantSetup.login(iciciPage, 'icici-user');
  await expect(iciciPage.locator('[data-testid="task-row"]')).toHaveCount(0);
  await expect(iciciPage.locator('[data-testid="empty-inbox"]')).toBeVisible();
});
```

## Contract Test (Spring Cloud Contract) — Consumer Side
```groovy
// contracts/task/claim-task-success.groovy (in Portal consumer repo)
Contract.make {
  request {
    method POST()
    url '/api/v1/tasks/task-123/claim'
    headers { contentType(applicationJson()) }
    body([])
  }
  response {
    status 200
    body([
      data: [taskId: 'task-123', status: 'CLAIMED', claimedBy: anyNonEmptyString()],
      meta: [requestId: anyNonEmptyString(), traceId: anyNonEmptyString()]
    ])
  }
}

// contracts/task/claim-task-conflict.groovy
Contract.make {
  request {
    method POST()
    url '/api/v1/tasks/task-already-claimed/claim'
  }
  response {
    status 409
    body([
      error: [
        code: 'TASK_ALREADY_CLAIMED',
        message: anyNonEmptyString(),
        details: [claimedBy: anyNonEmptyString(), claimedAt: anyNonEmptyString()]
      ]
    ])
  }
}
```

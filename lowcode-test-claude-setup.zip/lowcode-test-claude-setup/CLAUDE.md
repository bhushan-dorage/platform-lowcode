# Low-Code Workflow Platform — Test Project

## Identity
Automated test suite for the Low-Code Workflow Platform.
Architect: Bhushan | Role: Test design locked, Claude Code implements only.
Paired repo: platform-* service repos (one test repo mirrors each service repo).

## Test Stack (LOCKED — never suggest alternatives)
- JUnit 5 + Mockito + AssertJ (unit tests)
- Testcontainers (integration — PostgreSQL 16, Redis 7, Kafka 3.6, Keycloak 23, ClickHouse 23)
- ArchUnit (architecture rule enforcement)
- PIT / Pitest (mutation testing — threshold 70%)
- Spring Cloud Contract (consumer-driven contract tests)
- Gatling 3.9 (performance tests)
- Playwright (E2E — runs against SIT environment)
- REST Assured (security / API tests)
- WireMock (external API mocking — SendGrid, Twilio, KIE Server)
- Chaos Monkey for Spring Boot (chaos engineering)

## Platform Under Test Stack
- Java 21 + Spring Boot 3.3 | Flowable 6.8 | PostgreSQL 16 + Redis 7 + Kafka 3.6
- Keycloak 23 | HashiCorp Vault | Kubernetes + Istio | ClickHouse 23

## Critical Testing Rules
1. NEVER mock PostgreSQL, Kafka, or Redis — always use Testcontainers
2. EVERY data endpoint test MUST include a tenant isolation assertion
3. EVERY Flowable test MUST verify idempotency (run twice, assert same result)
4. NEVER hardcode tenant_id — always use TenantTestFixture helpers
5. Contract tests MUST run before any service is promoted DEV → SIT
6. Performance baseline (Sprint 7) must exist before any regression claim
7. Flaky test tolerance = zero at GA — quarantine and fix immediately

## Response Style
- No preamble. Test code first.
- Terse comments — no obvious ones.
- Always use AssertJ assertions, never JUnit assertEquals.
- When done: one-line summary of what was created.

## Quick Reference
→ Test infrastructure details:  `.claude/ARCHITECTURE_MAP.md`
→ Common test mistakes to avoid: `.claude/COMMON_MISTAKES.md`
→ Run commands & CI setup:       `.claude/QUICK_START.md`
→ Domain-specific test patterns: `docs/learnings/` (load on demand)

# Test Architecture Map

## Repo Layout — One Test Repo Per Service

```
github.com/org/
  platform-test-support/          ← Shared test library (imported by all test repos, test scope)
  platform-workflow-engine-tests/ ← Integration + contract tests for workflow engine
  platform-form-service-tests/    ← Integration + contract tests for form service
  platform-data-service-tests/    ← Integration + contract tests for data service
  platform-rules-service-tests/   ← Integration + contract tests for rules service
  platform-integration-service-tests/
  platform-audit-service-tests/
  platform-notification-service-tests/
  platform-studio-backend-tests/
  platform-entitlements-tests/    ← Dedicated entitlements engine tests (all 3 dimensions)
  platform-e2e-tests/             ← Playwright E2E journeys (runs against SIT)
  platform-performance-tests/     ← All Gatling scenarios
  platform-security-tests/        ← REST Assured security + ZAP integration
  platform-chaos-tests/           ← Chaos Monkey scenarios
```

## platform-test-support Library Structure
```
platform-test-support/
  src/test/java/com/platform/test/
    fixtures/
      TenantTestFixture.java       ← Creates/tears down test tenants (schema + Kafka + Keycloak)
      FlowableTestHelper.java      ← Deploy BPMN, start process, query/complete tasks
      EntitlementTestHelper.java   ← Create roles, assign policies, set actor attributes
      KafkaTestHelper.java         ← Publish events, consume + assert, wait-with-timeout
      AuditVerifier.java           ← Query ClickHouse, assert events captured correctly
      RedisTestHelper.java         ← Set/inspect cache state, simulate miss, validate TTLs
      WireMockSetup.java           ← Pre-configured mocks: SendGrid, Twilio, KIE Server
    containers/
      PlatformContainers.java      ← Singleton Testcontainers (PG, Redis, Kafka, Keycloak, CH)
    annotations/
      @TenantIntegrationTest       ← Meta-annotation: starts containers + TenantTestFixture
      @FlowableIntegrationTest     ← Meta-annotation: starts containers + Flowable
      @KafkaIntegrationTest        ← Meta-annotation: starts Kafka container
```

## Test Tenant Convention
| Tenant ID            | Tier         | DB Schema                    | Use For                          |
|----------------------|--------------|------------------------------|----------------------------------|
| test-enterprise      | ENTERPRISE   | test_enterprise_platform     | Main integration tests           |
| test-professional    | PROFESSIONAL | test_professional_platform   | Tier-specific behaviour tests    |
| test-starter         | STARTER      | shared_starter (RLS)         | Shared schema + RLS tests        |
| test-isolation-b     | ENTERPRISE   | test_isolation_b_platform    | Cross-tenant isolation only      |
| e2e-{runId}          | ENTERPRISE   | e2e_{runId}_platform         | E2E tests — created + torn down  |

## Testcontainers Stack
| Container        | Image                              | Singleton | Shared Via              |
|------------------|------------------------------------|-----------|-------------------------|
| PostgreSQL 16    | postgres:16-alpine                 | Yes       | PlatformContainers      |
| Redis 7          | redis:7-alpine                     | Yes       | PlatformContainers      |
| Kafka 3.6        | confluentinc/cp-kafka:7.5          | Yes       | PlatformContainers      |
| Keycloak 23      | quay.io/keycloak/keycloak:23       | Yes       | PlatformContainers      |
| ClickHouse 23    | clickhouse/clickhouse-server:23    | Yes       | PlatformContainers      |
| Flowable REST    | flowable/flowable-rest:6.8         | Yes       | FlowableIntegrationTest |
| WireMock         | wiremock/wiremock:3.3              | No        | Per test class          |

## CI Pipeline — Test Execution Points
| Stage              | Tests                                  | Trigger            | Gate       |
|--------------------|----------------------------------------|--------------------|------------|
| PR Check           | Unit + Integration + Contract + ArchUnit| Every PR           | Hard fail  |
| SIT Deploy         | Smoke + Tenant isolation suite         | Merge to main      | Hard fail  |
| Nightly SIT        | E2E + Performance + Security scan      | 2 AM daily         | Alert      |
| Weekly SIT         | Chaos scenarios                        | Sunday 2 AM        | Alert      |
| Pre-UAT Gate       | ZAP full scan + security scripts       | Manual + pipeline  | Hard fail  |
| GA Gate            | All suites green + zero flaky          | Sprint 26          | Hard fail  |

## Contract Test Flow
```
Consumer repo (Portal):
  defines stub → published to Artifactory on PR merge

Producer repo (Workflow Engine):
  mvn verify runs ContractVerificationTest
  downloads consumer stub from Artifactory
  spins up service → verifies stub against live service
  FAILS BUILD if contract broken
```

## Performance Baseline (Sprint 7)
Stored in: `platform-performance-tests/src/test/resources/baselines/`
- ProcessStartBurst_baseline.json
- TaskInboxLoad_baseline.json
- TaskClaimContention_baseline.json
- FormSubmission_baseline.json
- EntitlementCacheHit_baseline.json

Nightly comparison: if any metric regresses > 10% → Slack alert + Grafana annotation.

# Quick Start — Daily Test Commands

## Run Tests Locally

```bash
# Unit tests only (fast — no containers)
mvn test -Dgroups=unit

# Integration tests (spins up Testcontainers)
mvn verify -Dgroups=integration

# Contract tests (downloads consumer stubs from Artifactory)
mvn verify -Dgroups=contract

# All tests
mvn verify

# Single test class
mvn test -Dtest=TaskClaimServiceIT

# Single test method
mvn test -Dtest=TaskClaimServiceIT#concurrentClaim_tenThreads_onlyOneSucceeds

# Skip unit, run only integration
mvn verify -DskipUnitTests -Dgroups=integration
```

## Mutation Testing (PIT)
```bash
# Run PIT mutation testing (takes 5–10 min)
mvn org.pitest:pitest-maven:mutationCoverage

# View report
open target/pit-reports/index.html

# Threshold: build fails if mutation score < 70%
```

## ArchUnit
```bash
# ArchUnit runs as part of unit tests — no separate command
# To run only ArchUnit rules:
mvn test -Dtest=ArchitectureRulesTest
```

## Performance Tests (Gatling)
```bash
# Run all scenarios against SIT
export PLATFORM_SIT_URL=https://sit.platform.com
export PLATFORM_SIT_TOKEN=$(./scripts/get-sit-token.sh)
mvn gatling:test -pl platform-performance-tests

# Run single scenario
mvn gatling:test -pl platform-performance-tests \
  -Dgatling.simulationClass=ProcessStartBurstSimulation

# Compare against baseline
mvn gatling:test -pl platform-performance-tests \
  -Dcompare.baseline=true

# View Gatling report
open target/gatling/*/index.html
```

## E2E Tests (Playwright)
```bash
# Run all E2E journeys against SIT
export PLATFORM_SIT_URL=https://sit.platform.com
npx playwright test --project=chromium

# Run single journey
npx playwright test tests/loan-application-flow.spec.ts

# Run with UI (headed mode for debugging)
npx playwright test --headed --slow-mo=500

# View HTML report
npx playwright show-report

# Debug a specific test
npx playwright test --debug tests/tenant-isolation.spec.ts
```

## Security Tests
```bash
# Run REST Assured security suite against SIT
export PLATFORM_SIT_URL=https://sit.platform.com
mvn test -pl platform-security-tests -Dgroups=security

# Run ZAP scan (requires ZAP running on port 8090)
docker run -t owasp/zap2docker-stable zap-baseline.py \
  -t https://sit.platform.com \
  -r zap-report.html

# Tenant cross-contamination script
mvn test -pl platform-security-tests -Dtest=TenantCrossContaminationTest
```

## Contract Tests
```bash
# Publish consumer stubs to Artifactory (run from consumer repo)
mvn clean install -Pcontract-publish

# Verify producer against consumer stubs (run from producer repo)
mvn verify -Pcontract-verify

# List available stubs in Artifactory
curl https://artifactory.platform.com/api/storage/libs-release/com/platform/stubs/
```

## Testcontainers Tips
```bash
# Pre-pull images to speed up first run
docker pull postgres:16-alpine
docker pull redis:7-alpine
docker pull confluentinc/cp-kafka:7.5
docker pull quay.io/keycloak/keycloak:23
docker pull clickhouse/clickhouse-server:23
docker pull flowable/flowable-rest:6.8

# Check running containers during test (in another terminal)
docker ps --format "table {{.Names}}\t{{.Status}}\t{{.Ports}}"

# Disable Ryuk for CI (already set in PlatformContainers)
export TESTCONTAINERS_RYUK_DISABLED=true
```

## Claude Code Workflow (token-efficient)
```bash
# Start session — check context burn
/context

# Use Sonnet for test code generation
/model sonnet

# Switch to Opus only for complex test design decisions
/model opus

# Compact between unrelated test tasks
/compact

# Check cost
/cost
```

## Useful Assertions (AssertJ Quick Reference)
```java
// Collections
assertThat(list).hasSize(1).first().extracting("tenantId").isEqualTo("test-enterprise");
assertThat(list).isEmpty();
assertThat(list).extracting("status").containsOnly("CLAIMED");

// Exceptions
assertThatThrownBy(() -> service.claim(taskId, "wrong-tenant"))
  .isInstanceOf(TenantAccessViolationException.class)
  .hasMessageContaining("tenant");

// Kafka events (via KafkaTestHelper)
kafkaHelper.assertEventPublished("test-enterprise.task.events",
  event -> event.getEventType().equals("TASK_CLAIMED")
            && event.getResource().getId().equals(taskId));

// Audit (via AuditVerifier)
auditVerifier.assertEvent("test-enterprise", "TASK_CLAIMED", taskId);
```

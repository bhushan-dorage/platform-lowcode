# Common Test Mistakes — DO NOT REPEAT

## P0: Missing Tenant Isolation Assertions
- **No cross-tenant check**: Every test that creates data for tenantA MUST include an assertion
  that tenantB cannot see it. Missing this = test gives false confidence.
  ```java
  // WRONG — only tests happy path
  assertThat(taskClient.inbox("test-enterprise")).hasSize(1);

  // CORRECT — also verifies isolation
  assertThat(taskClient.inbox("test-enterprise")).hasSize(1);
  assertThat(taskClient.inbox("test-isolation-b")).isEmpty(); // ← mandatory
  ```
- **Hardcoded tenant_id**: Never write `"hsbc"` or `"icici"` in test code.
  Always use `TenantTestFixture.ENTERPRISE_TENANT` constants.

## P0: Mocking Infrastructure
- **Mocking PostgreSQL**: Never use H2 or in-memory DB. Always Testcontainers PostgreSQL.
  Schema routing, RLS, and FOR UPDATE SKIP LOCKED don't work in H2.
- **Mocking Kafka**: Never use EmbeddedKafka. Always Testcontainers Kafka.
  Topic naming, partition assignment, and consumer group rebalance behave differently.
- **Mocking Redis**: Never use Jedis mock. Always Testcontainers Redis.
  Redlock TTL behaviour is not reproducible with mocks.

## P0: Flowable Test Anti-Patterns
- **Not setting tenantId on process start**: Always call `.tenantId(TenantContext.get())` in test.
  Flowable silently accepts process starts without tenantId and puts them in wrong bucket.
- **Not waiting for async history**: After completing a task, assert history with
  `await().atMost(5, SECONDS).until(() -> historyService.count() > 0)`.
  History is async — direct assertion immediately after complete() will flake.
- **Sharing Flowable engine state between tests**: Always clean up process instances in
  `@AfterEach`. Leftover instances cause subsequent tests to see unexpected task counts.

## P1: Testcontainers Pitfalls
- **New container per test class**: Extremely slow. Use singleton PlatformContainers pattern
  with `@Container static` and Ryuk disabled for CI.
- **Not reusing Keycloak realm**: Realm creation is slow (~3s). Create realm once per test class
  in `@BeforeAll`, not per test in `@BeforeEach`.
- **Not waiting for Kafka topic creation**: After tenant provisioning, topics are created async.
  Always `KafkaTestHelper.waitForTopics(tenantPrefix, Duration.ofSeconds(10))` before producing.

## P1: Contract Test Mistakes
- **Producer verifying against own stub**: Contract tests must verify the CONSUMER's stub,
  not a stub written by the producer. Producer writing its own contract = no value.
- **Missing negative contract cases**: Always include contracts for error responses
  (409 TASK_ALREADY_CLAIMED, 404 NOT_FOUND, 403 ACCESS_DENIED) not just happy path 200.
- **Not publishing stub on merge**: Consumer stub must be published to Artifactory on every
  merge to main, not just on release. Producer CI downloads latest stub.

## P1: Performance Test Mistakes
- **Asserting without baseline**: Never claim "performance improved" without comparing
  to the Sprint 7 baseline stored in `baselines/`. Load the baseline JSON in every Gatling scenario.
- **Running Gatling against local/DEV**: Performance tests MUST run against SIT with
  production-equivalent data volumes. Local results are meaningless.
- **Single-tenant load test**: Always run burst scenarios with 3+ tenants simultaneously.
  Single-tenant load misses connection pool contention and Kafka consumer group issues.

## P1: E2E Test Mistakes
- **Not isolating E2E tenant**: Each E2E run MUST create a fresh `e2e-{runId}` tenant
  and tear it down after. Shared E2E tenant accumulates state and causes flaky tests.
- **Hardcoded SIT URLs**: Never hardcode `https://sit.platform.com`. Use
  `System.getenv("PLATFORM_SIT_URL")` — set in GitHub Actions secrets.
- **Not capturing screenshots on failure**: Every Playwright test MUST have
  `page.screenshot({ path: `screenshots/${testName}-${Date.now()}.png` })` in `afterEach`.

## P2: Assertion Quality
- **Using assertTrue instead of AssertJ**: `assertTrue(list.size() == 1)` gives no info on failure.
  `assertThat(list).hasSize(1)` shows actual content. Always use AssertJ.
- **Not asserting Kafka event content**: After a task claim, asserting only the HTTP response
  is insufficient. Always verify the Kafka event was published with correct tenantId, payload.
- **Not asserting audit events**: For any state-changing operation, always verify
  AuditVerifier.assertEvent(tenantId, eventType, resourceId) in integration tests.
